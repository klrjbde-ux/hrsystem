<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('employees', function (Blueprint $table) {
            $table->dropForeign(['relation']);
            $table->string('relation')->nullable()->change();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
       Schema::table('employees', function (Blueprint $table) {
            $table->unsignedBigInteger('relation')->nullable()->change();

            $table->foreign('relation')
                ->references('id')
                ->on('relation_contacts')
                ->onDelete('set null');
        });
    }
};
