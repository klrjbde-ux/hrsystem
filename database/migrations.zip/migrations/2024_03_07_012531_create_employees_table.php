<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateEmployeesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('employees', function (Blueprint $table) {
            $table->id();
            $table->string('firstname');
            $table->string('lastname');
            $table->string('personal_email')->unique();
            $table->string('gender');
            $table->date('dob');
            $table->string('emp_type');
            $table->string('emp_status');
            $table->string('designation');
            $table->string('department');
            $table->string('branch')->nullable();
            $table->date('joining_date');
            $table->string('manager')->nullable();
            $table->string('team')->nullable();
            $table->string('contact_no');
            $table->string('identity_no');
            $table->string('permanent_address');
            $table->string('current_address');
            $table->string('emergency_contact');
            $table->string('emergency_contact_address');
            $table->decimal('gross_salary', 20, 2)->nullable();
            $table->string('image')->nullable();
            $table->unsignedBigInteger('relation')->nullable();
            $table->foreign('relation')->references('id')->on('relation_contacts')->onDelete('set null');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
{
    Schema::table('employees', function (Blueprint $table) {
        // Check if foreign key exists before trying to drop it
        if (Schema::hasColumn('employees', 'relation')) {
            $foreignKeys = $table->getConnection()->getDoctrineSchemaManager()->listTableForeignKeys($table->getTable());
            foreach ($foreignKeys as $key) {
                if (in_array('relation', $key->getColumns())) {
                    $table->dropForeign(['relation']);
                    break;
                }
            }
            // Drop the column after dropping the foreign key
            $table->dropColumn('relation');
        }
    });

    Schema::dropIfExists('employees');
}

}
