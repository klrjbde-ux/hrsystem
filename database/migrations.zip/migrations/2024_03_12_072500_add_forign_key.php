<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddForignKey extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('employees', function (Blueprint $table) {
            // Add foreign key constraints
            $table->foreign('designation')->references('id')->on('designations')->onDelete('set null');
            $table->foreign('department')->references('id')->on('departments')->onDelete('set null');
            // $table->foreign('relation')->references('id')->on('relation_contacts')->onDelete('set null');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('employees', function (Blueprint $table) {
            // Drop foreign key constraints
            $table->dropForeign(['designation']);
            $table->dropForeign(['department']);
            $table->dropForeign(['relation']);

            // Drop the columns
            $table->dropColumn(['designation', 'department', 'relation']);
        });
    }
}
